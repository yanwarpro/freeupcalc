﻿FreeUp Calc — Ekstensi Chrome dan kalkulator web

Buka sebagai halaman web:
- Buka popup.html di browser.
- Kalkulator berjalan dan pengaturan tersimpan di browser yang sama.
- Deteksi otomatis tersedia saat dipasang sebagai ekstensi Chrome.

Pasang sebagai ekstensi Chrome:
1. Ekstrak ZIP ini.
2. Buka chrome://extensions di Chrome.
3. Aktifkan Developer mode.
4. Klik Load unpacked, lalu pilih folder hasil ekstrak yang berisi manifest.json.

Panduan lengkap: User_Guide_FreeUp_Calc.pdf.
